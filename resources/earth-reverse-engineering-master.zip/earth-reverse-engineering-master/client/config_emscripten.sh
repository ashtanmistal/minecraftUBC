#!/bin/bash

EMSCRIPTEN_PROTOBUF_SRC="$(echo ~)/Downloads/protobuf/src"
EMSCRIPTEN_PROTOBUF_LIB="$(echo ~)/Downloads/protobuf/src/.libs/libprotobuf.a"
EMSCRIPTEN_PROTOBUF_EXE="$(echo ~)/Downloads/protoc-3.9.2-osx-x86_64/bin/protoc"
