#!/bin/bash
g++ -c crn.cc
