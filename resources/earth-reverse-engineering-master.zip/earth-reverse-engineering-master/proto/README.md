Some data is still packed after decoding protobuf. See [rocktree_decoder.h](../client/rocktree_decoder.h) and [rocktree_ex.h](../client/rocktree_ex.h) for post-processing steps.
